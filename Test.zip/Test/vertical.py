import fitz  # PyMuPDF
import os

# === Folder containing PDFs ===
input_folder = "/home/user/Desktop/paddle_ocr_pipeline/output"

# === Process Each PDF in the Folder ===
for filename in os.listdir(input_folder):
    if filename.lower().endswith(".pdf"):
        input_pdf_path = os.path.join(input_folder, filename)

        try:
            doc = fitz.open(input_pdf_path)
        except Exception as e:
            print(f"❌ Failed to open PDF: {input_pdf_path}\n   ↳ {e}")
            continue

        output_pdf = fitz.open()

        # === Process Each Page: Keep Only Left Half ===
        for page in doc:
            rect = page.rect
            mid_x = rect.width / 2

            # Define the left half of the page
            left_rect = fitz.Rect(0, 0, mid_x, rect.height)

            # Create a new page using only the left half
            left_page = output_pdf.new_page(width=mid_x, height=rect.height)
            left_page.show_pdf_page(left_page.rect, doc, page.number, clip=left_rect)

        # === Overwrite the original PDF ===
        output_pdf.save(input_pdf_path)
        output_pdf.close()
        doc.close()

        print(f"✅ Replaced with left-half-only PDF: {input_pdf_path}")

print("🎉 All PDFs in the folder processed.")
