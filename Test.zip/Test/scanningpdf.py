import fitz  # PyMuPDF
import os
import img2pdf
import sys

# === Ask File Type ===
choice = input("Do you want to process a 'pdf' or a 'folder' of PDFs? ").strip().lower()

# === Output Directory ===
output_root = "/home/user/Desktop/paddle_ocr_pipeline/outpdf"
os.makedirs(output_root, exist_ok=True)

# === Function to Convert PDF to Images and Save Scanned PDF ===
def process_pdf(input_pdf_path):
    base_name = os.path.splitext(os.path.basename(input_pdf_path))[0]
    output_subdir = os.path.join(output_root, base_name)
    os.makedirs(output_subdir, exist_ok=True)

    print(f"Converting '{base_name}' to images...")

    doc = fitz.open(input_pdf_path)
    image_paths = []

    for page_num in range(len(doc)):
        page = doc.load_page(page_num)
        pix = page.get_pixmap(dpi=200)
        image_path = os.path.join(output_subdir, f"page_{page_num + 1}.png")
        pix.save(image_path)
        image_paths.append(image_path)

    doc.close()

    if not image_paths:
        print(f"⚠️ No pages found in {input_pdf_path}")
        return

    output_pdf_path = os.path.join(output_subdir, f"{base_name}_scanned.pdf")
    with open(output_pdf_path, "wb") as f:
        f.write(img2pdf.convert(image_paths))

    print(f"✅ Scanned PDF saved at: {output_pdf_path}")

# === Single PDF Mode ===
if choice == "pdf":
    input_pdf_path = input("Enter the full path of the PDF file: ").strip()

    if not os.path.isfile(input_pdf_path) or not input_pdf_path.lower().endswith(".pdf"):
        print("❌ Invalid PDF file path.")
        sys.exit(1)

    process_pdf(input_pdf_path)

# === Folder Mode ===
elif choice == "folder":
    input_pdf_dir = input("Enter the folder path containing PDFs: ").strip()

    if not os.path.isdir(input_pdf_dir):
        print("❌ Invalid folder path.")
        sys.exit(1)

    pdf_files = [f for f in os.listdir(input_pdf_dir) if f.lower().endswith(".pdf")]
    if not pdf_files:
        print("⚠️ No PDF files found in the folder.")
        sys.exit(1)

    for pdf_file in pdf_files:
        full_path = os.path.join(input_pdf_dir, pdf_file)
        print(f"\nProcessing: {pdf_file}")
        process_pdf(full_path)

    print("\nAll PDFs processed and scanned successfully!")

# === Invalid Choice ===
else:
    print("❌ Invalid choice. Please type 'pdf' or 'folder'.")
