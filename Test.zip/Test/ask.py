import subprocess

def run_script(script_name):
    print(f"\nRunning: {script_name}")
    try:
        subprocess.run(["python", script_name], check=True)
        print(f"✅ Finished: {script_name}")
    except subprocess.CalledProcessError as e:
        print(f"❌ Error running {script_name}: {e}")
        exit(1)

def main():
    print("PDF Translation Pipeline (Full version including pre-scan steps)")
    print("Starting full translation pipeline...\n")



    # === Core scan-based translation pipeline ===
    run_script("scanningpdf.py")           # Step 1: Convert scanned PDFs to images
    run_script("ocr.py")                   # Step 2: Run OCR with PaddleOCR
    run_script("translation.py")           # Step 3: Translate paragraphs to English
    run_script("pagecombine.py")           # Step 4: Overlay translated text on images and export per-PDF
    run_script("vertical.py")              # Step 5: Cut each PDF vertically (keep only left half)

    print("\n Core translation pipeline completed successfully!")

    # === Optional summarization ===
    print("\nDo you want to generate a summary from the translated content?")
    summary_choice = input("Type 'yes' to summarize or 'no' to skip: ").strip().lower()

    if summary_choice == "yes":
        run_script("summary.py")           # Step 6: Summarize all translated text
        print("Summarization completed.")
    else:
        print("✅ Skipping summarization. Translation pipeline finished!")

if __name__ == "__main__":
    main()
# This script orchestrates the entire PDF translation pipeline, including pre-scan steps.