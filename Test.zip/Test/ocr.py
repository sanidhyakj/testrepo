# ocr.py
from paddleocr import PaddleOCR
import os
import shutil

# === Common Output Directory ===
output_root_dir = "/home/user/Desktop/paddle_ocr_pipeline/outpdf"
os.makedirs(output_root_dir, exist_ok=True)

import re

def natural_sort_key(s):
    return [int(text) if text.isdigit() else text.lower() for text in re.split(r'(\d+)', s)]


# === Initialize OCR ===
ocr = PaddleOCR(
    text_detection_model_name="PP-OCRv5_mobile_det",
    text_recognition_model_name="PP-OCRv5_mobile_rec",
    use_doc_orientation_classify= True,
    use_doc_unwarping= False,
    use_textline_orientation= False,
)

# === Detect Mode: Single PDF or Folder of PDFs ===
subdirs = [d for d in os.listdir(output_root_dir) if os.path.isdir(os.path.join(output_root_dir, d))]

# === Single PDF Mode ===
if all(f.lower().endswith(".png") for f in os.listdir(output_root_dir)):
    print("📄 Detected: Single PDF Mode")
    image_dir = output_root_dir
    image_files = sorted([f for f in os.listdir(image_dir) if f.lower().endswith(".png")], key=natural_sort_key)

    for img_file in image_files:
        image_path = os.path.join(image_dir, img_file)
        base_name = os.path.splitext(img_file)[0]
        print(f"[🔍 OCR] → {img_file}")

        results = ocr.predict(image_path)
        for res in results:
            res.print()
            res.save_to_img(image_dir)
            res.save_to_json(image_dir)

            # Rename outputs
            res_img_path = os.path.join(image_dir, "res.png")
            res_json_path = os.path.join(image_dir, "res.json")
            if os.path.exists(res_img_path):
                shutil.move(res_img_path, os.path.join(image_dir, f"{base_name}_res.png"))
            if os.path.exists(res_json_path):
                shutil.move(res_json_path, os.path.join(image_dir, f"{base_name}_res.json"))

    print(f"✅ OCR results saved in: {output_root_dir}")

# === Folder Mode ===
else:
    print("📁 Detected: Folder Mode")
    for subdir in subdirs:
        pdf_output_dir = os.path.join(output_root_dir, subdir)
        image_files = sorted([f for f in os.listdir(pdf_output_dir) if f.lower().endswith(".png")], key=natural_sort_key)


        if not image_files:
            continue  # Skip if no PNGs found

        print(f"\n📄 OCR for PDF: {subdir}")
        for img_file in image_files:
            image_path = os.path.join(pdf_output_dir, img_file)
            base_name = os.path.splitext(img_file)[0]
            print(f"[🔍 OCR] → {img_file}")

            results = ocr.predict(image_path)
            for res in results:
                res.print()
                res.save_to_img(pdf_output_dir)
                res.save_to_json(pdf_output_dir)

                # Rename outputs
                res_img_path = os.path.join(pdf_output_dir, "res.png")
                res_json_path = os.path.join(pdf_output_dir, "res.json")
                if os.path.exists(res_img_path):
                    shutil.move(res_img_path, os.path.join(pdf_output_dir, f"{base_name}_res.png"))
                if os.path.exists(res_json_path):
                    shutil.move(res_json_path, os.path.join(pdf_output_dir, f"{base_name}_res.json"))

    print("\n🎉 All PDFs scanned and OCR'd successfully!")
    print(f"📂 Output folders saved in: {output_root_dir}")
