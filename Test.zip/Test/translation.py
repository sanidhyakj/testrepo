import os
import json
import re
import logging
import numpy as np

# === Logging ===
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# === Configuration ===
root_dir = "/home/user/Desktop/paddle_ocr_pipeline/outpdf"

# === Chinese character detector ===
def is_chinese(text):
    return bool(re.search(r'[\u4e00-\u9fff]', text))
import requests
from concurrent.futures import ThreadPoolExecutor, as_completed
BASE_URL = "http://77.37.126.131:8080/v1"
API_KEY = "hf-1234567"
MODEL_NAME = "NousResearch/Hermes-3-Llama-3.1-8B"
MAX_TOKENS = 12000
MAX_WORKERS = 16
BATCH_SIZE = 200
HEADERS = {
    "Authorization": f"Bearer {API_KEY}",
    "Content-Type": "application/json"
}

def translate_text(text, src_lang="zh", tgt_lang="en"):
    prompt = f"Translate the following text from {src_lang} to {tgt_lang}:\n{text}"

    payload = {
        "model": MODEL_NAME,
        "max_tokens": MAX_TOKENS,
        "messages": [
            {"role": "system", "content": "You are a translation assistant. Translate text from Chinese to English without any explanation, pinyin, or definition. Just give the plain English translation."},
            {"role": "user", "content": prompt}
        ]
    }
    
    try:
        response = requests.post(f"{BASE_URL}/chat/completions", headers=HEADERS, json=payload)
        if response.status_code == 200:
            return response.json()['choices'][0]['message']['content'].strip()
        else:
            logger.error(f"❌ Translation API failed: {response.status_code} - {response.text}")
            return "???"
    except Exception as e:
        logger.error(f"❌ Exception during translation request: {e}")
        return "???"
# === Worker for parallel processing ===
def translate_paragraph(para, index):
    translated = translate_text(para)
    return (index, translated)

# === Batch translator ===
def batch_translate(paragraphs):
    results = [None] * len(paragraphs)

    for i in range(0, len(paragraphs), BATCH_SIZE):
        batch = paragraphs[i:i + BATCH_SIZE]
        logger.info(f" Translating batch {i // BATCH_SIZE + 1} ({i}–{i + len(batch) - 1})")

        with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
            futures = {
                executor.submit(translate_paragraph, para, i + j): j
                for j, para in enumerate(batch)
            }

            for future in as_completed(futures):
                try:
                    index, translation = future.result()
                    results[index] = translation
                except Exception as e:
                    logger.error(f"❌ Error during translation: {e}")

        logger.info(f"✅ Finished batch {i // BATCH_SIZE + 1}")

    return results


# === Local spacing-based paragraph logic ===
def group_lines_into_paragraphs(lines):
    lines = sorted(lines, key=lambda line: line["box"][1])

    # Step 2: Helper function to estimate the typical vertical spacing between lines
    def estimate_local_spacing(line_index):
        vertical_gaps = []

        # Check up to 2 lines before and 2 lines after the current line
        for nearby_offset in [-2, -1, 1, 2]:
            neighbor_index = line_index + nearby_offset
            next_index = neighbor_index + 1

            # Make sure both neighbor and next line indices are valid
            if 0 <= neighbor_index < len(lines) - 1:
                # Get the bottom y-coordinate of the current neighbor line
                bottom_of_line = lines[neighbor_index]["box"][3]
                # Get the top y-coordinate of the next line
                top_of_next_line = lines[next_index]["box"][1]
                
                # Calculate the vertical gap between them
                gap = top_of_next_line - bottom_of_line

                # Keep only reasonable gaps: ignore negative/zero gaps or abnormally large ones (>100px)
                if 0 < gap < 100:
                    vertical_gaps.append(gap)

        # Return the median of all nearby gaps — a robust estimate of "normal" spacing
        return np.median(vertical_gaps) if vertical_gaps else 0

    # Step 3: Helper function to decide if two lines should be part of the same paragraph
    def lines_should_merge(line1, line2, line_index):
        # Extract bounding box coordinates: (left, top, right, bottom)
        x1_min, y1_min, x1_max, y1_max = line1["box"]
        x2_min, y2_min, x2_max, y2_max = line2["box"]

        # Calculate height of both lines
        height1 = y1_max - y1_min
        height2 = y2_max - y2_min
        average_height = (height1 + height2) / 2

        # Calculate how much vertical space exists between the bottom of line1 and top of line2
        vertical_gap_between_lines = y2_min - y1_max

        # Check horizontal alignment
        indent_difference = abs(x2_min - x1_min)
        center_alignment_difference = abs((x2_min + x2_max) / 2 - (x1_min + x1_max) / 2)
        #trailing_difference = abs(x2_max - x1_max) 
        

        # Estimate the usual vertical spacing around line1
        local_typical_gap = estimate_local_spacing(line_index)

        # right_bottom_x1 = x1_max
        # right_bottom_x2 = x2_max
        #right_x_difference = abs(right_bottom_x2 - right_bottom_x1)

        if indent_difference > average_height * 0.1   and center_alignment_difference > average_height * 0.1 :
            return False

       

        # Rule 1: Too much vertical space? Probably a paragraph break
        if vertical_gap_between_lines > local_typical_gap * 1.3:
            return False
        # Rule 2: Line2 is highly indented and misaligned? Likely a new paragraph
        
         # Instead of average_height * 1.0
        #if trailing_difference > max(average_height, local_typical_gap) * 2.0:
         #   return False

        # Rule 2: Line2 is highly indented and misaligned? Likely a new paragraph
        
        # If neither of the rules break, keep both lines in the same paragraph
        return True

    # Step 4: Go through each line and group them into paragraphs
    paragraphs = []
    current_paragraph = [lines[0]]  # Initialize with the first line

    for i in range(1, len(lines)):
        previous_line = lines[i - 1]
        current_line = lines[i]

        # Check if current line continues the same paragraph
        if lines_should_merge(previous_line, current_line, i - 1):
            current_paragraph.append(current_line)
        else:
            # Paragraph break detected, so save current paragraph and start a new one
            paragraphs.append(current_paragraph)
            current_paragraph = [current_line]

    # After the loop ends, don't forget to add the last paragraph
    if current_paragraph:
        paragraphs.append(current_paragraph)

    # Return the list of paragraph groups, each a list of lines
    return paragraphs


def process_jsons_in_dir(json_dir):
    for filename in os.listdir(json_dir):
        if not filename.endswith("_res.json"):
            continue

        input_path = os.path.join(json_dir, filename)
        base_name = filename.replace("_res.json", "")
        output_path = os.path.join(json_dir, base_name + "_paragraphs.json")

        logger.info(f"\n Processing: {input_path}")

        # Load the JSON file
        try:
            with open(input_path, "r", encoding="utf-8") as f:
                data = json.load(f)
        except Exception as e:
            logger.error(f"❌ Failed to read JSON: {e}")
            continue

        texts = data.get("rec_texts", [])
        boxes = data.get("rec_boxes", [])

        if not texts or not boxes or len(texts) != len(boxes):
            logger.warning(f"⚠️ Skipping {filename} due to missing or mismatched 'rec_texts' and 'rec_boxes'")
            continue

        lines = []
        for text, box in zip(texts, boxes):
            try:
                x_min, _, x_max, _ = box
                x_center = (x_min + x_max) / 2
                lines.append({"text": text, "box": box, "x_center": x_center})
            except Exception as e:
                logger.warning(f"⚠️ Invalid box: {box} — {e}")

        # Group into paragraphs
        try:
            para_lines = group_lines_into_paragraphs(lines)
        except Exception as e:
            logger.error(f"❌ Error grouping lines into paragraphs: {e}")
            continue

        logger.info(f"📁 Total paragraphs formed: {len(para_lines)}")

        # Prepare paragraphs and their metadata
        para_texts = []
        meta_info = []

        for para in para_lines:
            try:
                para_text = ''.join([l["text"] for l in para])
                boxes = [l["box"] for l in para]
                x_mins, y_mins, x_maxs, y_maxs = zip(*[(b[0], b[1], b[2], b[3]) for b in boxes])
                meta_info.append({
                    "para_text": para_text,
                    "top_left": [min(x_mins), min(y_mins)],
                    "bottom_right": [max(x_maxs), max(y_maxs)]
                })
                para_texts.append(para_text)
            except Exception as e:
                logger.warning(f"⚠️ Failed to prepare paragraph: {e}")
                continue

        # Identify Chinese paragraphs to translate
        to_translate = []
        trans_indices = []

        for i, text in enumerate(para_texts):
            if is_chinese(text):
                logger.info(f"[P{i+1}] Queued for translation → {text[:60]}...")
                to_translate.append(text)
                trans_indices.append(i)

        # Translate using batch system
        translated_texts = batch_translate(to_translate)

        # Build final output with translated paragraphs
        final_paragraphs = []
        translation_output = []

        for idx, info in enumerate(meta_info):
            original_text = info["para_text"]
            if idx in trans_indices:
                trans_idx = trans_indices.index(idx)
                translation = translated_texts[trans_idx]
            else:
                translation = original_text

            final_paragraphs.append({
                "text": original_text,
                "translation": translation,
                "top_left": info["top_left"],
                "bottom_right": info["bottom_right"]
            })

            translation_output.append({
                "original": original_text,
                "translation": translation
            })

        # Save final JSON output
        try:
            output_data = {
                "paragraphs": final_paragraphs,
                "translations": translation_output
            }
            with open(output_path, "w", encoding="utf-8") as f:
                json.dump(output_data, f, ensure_ascii=False, indent=2)
            logger.info(f"✅ Saved paragraph output to: {output_path}")
        except Exception as e:
            logger.error(f"❌ Failed to write output file: {e}")


# === Detect structure ===
def main():
    json_files = [f for f in os.listdir(root_dir) if f.endswith("_res.json")]
    if json_files:
        logger.info("📄 Detected: Single PDF Mode")
        process_jsons_in_dir(root_dir)
    else:
        logger.info("📁 Detected: Folder Mode")
        for subdir in os.listdir(root_dir):
            subfolder_path = os.path.join(root_dir, subdir)
            if os.path.isdir(subfolder_path):
                logger.info(f"\n📁 Entering: {subdir}")
                process_jsons_in_dir(subfolder_path)

if __name__ == "__main__":
    main()









# Algorithm designed to interpret documents with more than one text column.

# # === Group lines into paragraphs with column===
# def group_lines_into_columns(lines, x_threshold=50, min_column_gap=30):
#     lines = sorted(lines, key=lambda line: line["box"][0])
#     columns = []

#     for line in lines:
#         x_min = line["box"][0]
#         placed = False

#         for col in columns:
#             mean_x = np.mean([l["box"][0] for l in col])
#             if abs(x_min - mean_x) < x_threshold:
#                 col.append(line)
#                 placed = True
#                 break

#         if not placed:
#             if all(abs(x_min - np.mean([l["box"][0] for l in c])) > min_column_gap for c in columns):
#                 columns.append([line])
#             else:
#                 closest_col = min(columns, key=lambda c: abs(x_min - np.mean([l["box"][0] for l in c])))
#                 closest_col.append(line)

#     return columns

# # === Local spacing-based paragraph logic ===
# def group_lines_into_paragraphs(lines):
#     lines = sorted(lines, key=lambda line: line["box"][1])

#     # Step 2: Helper function to estimate the typical vertical spacing between lines
#     def estimate_local_spacing(line_index):
#         vertical_gaps = []

#         # Check up to 2 lines before and 2 lines after the current line
#         for nearby_offset in [-2, -1, 1, 2]:
#             neighbor_index = line_index + nearby_offset
#             next_index = neighbor_index + 1

#             # Make sure both neighbor and next line indices are valid
#             if 0 <= neighbor_index < len(lines) - 1:
#                 # Get the bottom y-coordinate of the current neighbor line
#                 bottom_of_line = lines[neighbor_index]["box"][3]
#                 # Get the top y-coordinate of the next line
#                 top_of_next_line = lines[next_index]["box"][1]
                
#                 # Calculate the vertical gap between them
#                 gap = top_of_next_line - bottom_of_line

#                 # Keep only reasonable gaps: ignore negative/zero gaps or abnormally large ones (>100px)
#                 if 0 < gap < 100:
#                     vertical_gaps.append(gap)

#         # Return the median of all nearby gaps — a robust estimate of "normal" spacing
#         return np.median(vertical_gaps) if vertical_gaps else 0

#     # Step 3: Helper function to decide if two lines should be part of the same paragraph
#     def lines_should_merge(line1, line2, line_index):
#         # Extract bounding box coordinates: (left, top, right, bottom)
#         x1_min, y1_min, x1_max, y1_max = line1["box"]
#         x2_min, y2_min, x2_max, y2_max = line2["box"]

#         # Calculate height of both lines
#         height1 = y1_max - y1_min
#         height2 = y2_max - y2_min
#         average_height = (height1 + height2) / 2

#         # Calculate how much vertical space exists between the bottom of line1 and top of line2
#         vertical_gap_between_lines = y2_min - y1_max

#         # Check horizontal alignment
#         indent_difference = abs(x2_min - x1_min)  # how far the second line is indented
#         center_alignment_difference = abs(
#             (x2_min + x2_max) / 2 - (x1_min + x1_max) / 2
#         )  # difference in center positions

#         # Estimate the usual vertical spacing around line1
#         local_typical_gap = estimate_local_spacing(line_index)

#         # Rule 1: Too much vertical space? Probably a paragraph break
#         if vertical_gap_between_lines > local_typical_gap * 1.2:
#             return False

#         # Rule 2: Line2 is highly indented and misaligned? Likely a new paragraph
#         if indent_difference > average_height * 0.6 and center_alignment_difference > average_height * 0.5:
#             return False

#         # If neither of the rules break, keep both lines in the same paragraph
#         return True

#     # Step 4: Go through each line and group them into paragraphs
#     paragraphs = []
#     if not lines:
#          return []

#     current_paragraph = [lines[0]]
#   # Initialize with the first line

#     for i in range(1, len(lines)):
#         previous_line = lines[i - 1]
#         current_line = lines[i]

#         # Check if current line continues the same paragraph
#         if lines_should_merge(previous_line, current_line, i - 1):
#             current_paragraph.append(current_line)
#         else:
#             # Paragraph break detected, so save current paragraph and start a new one
#             paragraphs.append(current_paragraph)
#             current_paragraph = [current_line]

#     # After the loop ends, don't forget to add the last paragraph
#     if current_paragraph:
#         paragraphs.append(current_paragraph)

#     # Return the list of paragraph groups, each a list of lines
#     return paragraphs


# def group_lines_with_column_awareness(lines, x_threshold=50, min_column_gap=30):
#     columns = group_lines_into_columns(lines, x_threshold, min_column_gap)
#     paragraphs = []

#     for col in columns:
#         col = sorted(col, key=lambda l: l["box"][1])
#         paragraphs.extend(group_lines_into_paragraphs(col))

#     return paragraphs