
import os
import subprocess
import shutil
import zipfile
import tempfile
from PyPDF2 import PdfReader

# Input and Output directories
input_dir = "/home/user/Desktop/paddle_ocr_pipeline/cn_data"
output_dir = "/home/user/Desktop/paddle_ocr_pipeline/cn_data_translated"

# Extensions that can be converted to PDF
convert_extensions = [
    ".doc", ".docx", ".odt", ".rtf",              # Word
    ".xls", ".xlsx", ".ods", ".csv",              # Excel
    ".ppt", ".pptx", ".odp",                      # PowerPoint
    ".png", ".jpg", ".jpeg", ".bmp", ".tiff"      # Images
]

copy_pdf_files = True

def is_valid_pdf(file_path):
    try:
        with open(file_path, "rb") as f:
            PdfReader(f)
        return True
    except Exception as e:
        print(f"⚠️ Skipping invalid PDF: {file_path}\n   ↳ Reason: {e}")
        return False

def convert_to_pdf(file_path, output_folder):
    try:
        subprocess.run([
            "libreoffice",
            "--headless",
            "--convert-to", "pdf",
            "--outdir", output_folder,
            file_path
        ], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=True)
        return True
    except subprocess.CalledProcessError as e:
        print(f"❌ Failed to convert: {file_path}\n   ↳ Error: {e}")
        return False

def safe_copy_pdf(source_path, destination_path):
    if is_valid_pdf(source_path):
        try:
            shutil.copy2(source_path, destination_path)
            print(f"📄 Copied valid PDF: {source_path}")
        except Exception as e:
            print(f"❌ Error copying PDF: {source_path}\n   ↳ {e}")
    else:
        print(f"🚫 Skipped invalid/corrupt PDF: {source_path}")

# Walk through input directory
for root, _, files in os.walk(input_dir):
    for file in files:
        ext = os.path.splitext(file)[1].lower()
        input_path = os.path.join(root, file)
        relative_path = os.path.relpath(root, input_dir)
        target_dir = os.path.join(output_dir, relative_path)
        os.makedirs(target_dir, exist_ok=True)

        if ext in convert_extensions:
            print(f"📄 Converting: {input_path}")
            convert_to_pdf(input_path, target_dir)

        elif ext == ".pdf" and copy_pdf_files:
            destination_pdf = os.path.join(target_dir, file)
            safe_copy_pdf(input_path, destination_pdf)

        elif ext == ".zip":
            print(f"📦 Extracting ZIP: {input_path}")
            with tempfile.TemporaryDirectory() as tmpdir:
                try:
                    with zipfile.ZipFile(input_path, 'r') as zip_ref:
                        zip_ref.extractall(tmpdir)
                except zipfile.BadZipFile as e:
                    print(f"❌ Cannot extract ZIP (corrupt): {input_path}\n   ↳ {e}")
                    continue

                for subroot, _, subfiles in os.walk(tmpdir):
                    for subfile in subfiles:
                        sub_ext = os.path.splitext(subfile)[1].lower()
                        sub_path = os.path.join(subroot, subfile)

                        if sub_ext in convert_extensions:
                            print(f"  ↳ Converting extracted: {sub_path}")
                            convert_to_pdf(sub_path, target_dir)

                        elif sub_ext == ".pdf" and copy_pdf_files:
                            dest_path = os.path.join(target_dir, subfile)
                            safe_copy_pdf(sub_path, dest_path)

                # All files are processed, extracted folder will be auto-deleted as it's a TemporaryDirectory

print("✅ All files processed.")
