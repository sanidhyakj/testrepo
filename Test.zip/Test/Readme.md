⚠️ Python 3.12.3 is required. Please make sure it's installed before continuing.
📘 For full details, refer to whole.txt.

# Paddle OCR PDF Translation Pipeline

A comprehensive pipeline for processing scanned PDFs: converting them to images, extracting text with OCR, grouping and translating paragraphs, overlaying translations on images, and generating summaries.  
Designed for both single and batch PDF workflows, with a focus on Chinese-to-English translation.

---

## Table of Contents

- [Features](#features)
- [Workflow Overview](#workflow-overview)
- [Installation](#installation)
- [Usage](#usage)
- [Script Details](#script-details)
- [Folder Structure](#folder-structure)
- [Customization](#customization)
- [Troubleshooting](#troubleshooting)
- [License](#license)

---

## Features

- **PDF to Image Conversion:** Converts each page of a PDF into a high-quality PNG image.
- **OCR Extraction:** Uses PaddleOCR to extract text and layout from images.
- **Paragraph Grouping:** Groups recognized lines into logical paragraphs based on spatial layout.
- **Chinese-to-English Translation:** Translates detected Chinese text using HuggingFace models or API.
- **Overlay & Export:** Renders translated text onto images and exports as new PDFs.
- **Summarization:** Generates concise summaries of translated content using a local LLM (Ollama/Mistral).
- **Batch & Single PDF Support:** Handles both individual PDFs and folders of PDFs.
- **Interactive Pipeline:** Guides the user through each step with prompts and progress messages.

---

## Workflow Overview

The pipeline is orchestrated by `ask.py` and consists of the following steps:

1. **PDF Scanning (`scanningpdf.py`):**
   - Converts PDFs (single or folder) to PNG images.
   - Creates a "scanned" PDF from these images for each document.

2. **OCR (`ocr.py`):**
   - Runs OCR on each image.
   - Saves results as annotated images and JSON files containing recognized text and bounding boxes.

3. **Translation (`translation.py`):**
   - Groups OCR lines into paragraphs based on vertical and horizontal alignment.
   - Translates Chinese paragraphs to English.
   - Outputs paragraph JSON files with both original and translated text.

4. **Overlay & Export (`pagecombine.py`):**
   - Overlays translated text onto images at the correct positions.
   - Exports a new PDF with translations for each document.

5. **Summarization (`summary.py`, optional):**
   - Loads all translated paragraphs for each document.
   - Uses a local LLM (Ollama/Mistral) to summarize content.
   - Saves summary as a PDF.

---
