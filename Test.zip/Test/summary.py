import os
import json
import requests
from pathlib import Path
from fpdf import FPDF
from langchain_core.documents import Document
from langchain.prompts import PromptTemplate
from transformers import AutoTokenizer

# === Configuration ===
intermediate_root = "/home/user/Desktop/paddle_ocr_pipeline/outpdf"
output_root = "/home/user/Desktop/paddle_ocr_pipeline/output"
os.makedirs(output_root, exist_ok=True)

API_KEY = "hf-1234567"
BASE_URL = "http://77.37.126.131:8080/v1"
MODEL_NAME = "NousResearch/Hermes-3-Llama-3.1-8B"
MAX_INPUT_TOKENS = 4000
MAX_OUTPUT_TOKENS = 1024

# === Load tokenizer (offline or pre-downloaded) ===
tokenizer = AutoTokenizer.from_pretrained("NousResearch/Hermes-3-Llama-3.1-8B")

# === Ask word limit ===
try:
    word_limit = int(input("🔢 Enter desired number of words in summary (e.g., 100, 200, 500): ").strip())
    if word_limit < 10:
        raise ValueError
except ValueError:
    print("⚠️ Invalid input. Defaulting to 200 words.")
    word_limit = 200

# === Prompt Template ===
map_prompt_template = f"Write a summary of the following text in about {word_limit} words:\n{{text}}"
map_prompt = PromptTemplate(input_variables=["text"], template=map_prompt_template)

# === Summarization Request ===
def summarize_with_model(prompt_text):
    try:
        response = requests.post(
            f"{BASE_URL}/chat/completions",
            headers={
                "Authorization": f"Bearer {API_KEY}",
                "Content-Type": "application/json"
            },
            json={
                "model": MODEL_NAME,
                "messages": [
                    {"role": "system", "content": "You are a helpful assistant that summarizes text."},
                    {"role": "user", "content": prompt_text}
                ],
                "max_tokens": MAX_OUTPUT_TOKENS,
                "temperature": 0.3
            },
            timeout=120
        )
        response.raise_for_status()
        return response.json()["choices"][0]["message"]["content"].strip()
    except Exception as e:
        print(f"❌ Local model error: {e}")
        if hasattr(e, 'response') and e.response is not None:
            print("🔎 Response content:", e.response.text)
        return None

# === Chunk paragraphs safely ===
def chunk_paragraphs(paragraphs, max_tokens=MAX_INPUT_TOKENS):
    chunks = []
    current_chunk = []
    token_count = 0

    for para in paragraphs:
        tokens = tokenizer.encode(para, add_special_tokens=False)
        if token_count + len(tokens) > max_tokens:
            if current_chunk:
                chunks.append(current_chunk)
            current_chunk = [para]
            token_count = len(tokens)
        else:
            current_chunk.append(para)
            token_count += len(tokens)

    if current_chunk:
        chunks.append(current_chunk)

    return chunks

# === Process folders ===
for folder_name in sorted(os.listdir(intermediate_root)):
    folder_path = os.path.join(intermediate_root, folder_name)
    if not os.path.isdir(folder_path):
        continue

    print(f"\n📁 Summarizing folder: {folder_name}")
    all_texts = []

    # Collect paragraphs
    for file in sorted(os.listdir(folder_path)):
        if file.endswith("_paragraphs.json"):
            file_path = os.path.join(folder_path, file)
            try:
                with open(file_path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    for para in data.get("paragraphs", []):
                        translation = para.get("translation", "").strip()
                        if translation:
                            all_texts.append(translation)
            except Exception as e:
                print(f"⚠️ Failed to read {file_path}: {e}")

    if not all_texts:
        print(f"❌ No translated text in {folder_name}. Skipping.")
        continue

    # Chunk safely by token length
    text_chunks = chunk_paragraphs(all_texts)
    summaries = []

    # Summarize each chunk
    for idx, chunk in enumerate(text_chunks):
        chunk_text = "\n".join(chunk)
        prompt = map_prompt.format(text=chunk_text)
        print(f"🧠 Summarizing chunk {idx+1}/{len(text_chunks)}...")
        summary = summarize_with_model(prompt)
        if summary:
            summaries.append(summary)

    # Final summary
    final_prompt = map_prompt.format(text="\n".join(summaries))
    print("🧠 Generating final summary...")
    final_summary = summarize_with_model(final_prompt)

    if not final_summary:
        print(f"❌ Final summarization failed for {folder_name}")
        continue

    print("✅ Final summary ready!")

    # === Save to PDF ===
    pdf_output_path = os.path.join(output_root, f"{folder_name}_summary.pdf")
    try:
        pdf = FPDF()
        pdf.add_page()
        pdf.set_auto_page_break(auto=True, margin=15)
        pdf.set_font("Arial", size=12)

        for line in final_summary.split("\n"):
            pdf.multi_cell(0, 10, line)

        pdf.output(pdf_output_path)
        print(f"📄 Summary PDF saved: {pdf_output_path}")
    except Exception as e:
        print(f"❌ Failed to write PDF for {folder_name}: {e}")
