import os
import json
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
from tqdm import tqdm

# === Paths ===
input_dir = "/home/user/Desktop/paddle_ocr_pipeline/outpdf"
output_root = "/home/user/Desktop/paddle_ocr_pipeline/output"
default_font_path = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"
fallback_font_path = "/usr/share/fonts/truetype/freefont/FreeSans.ttf"



# === Ensure output dir ===
os.makedirs(output_root, exist_ok=True)

# === Font path fallback ===
font_path = default_font_path if Path(default_font_path).exists() else fallback_font_path

# === Discover folders ===
folders_to_process = []
if any(f.endswith("_paragraphs.json") for f in os.listdir(input_dir)):
    folders_to_process.append(input_dir)
else:
    folders_to_process.extend([
        os.path.join(input_dir, f)
        for f in sorted(os.listdir(input_dir))
        if os.path.isdir(os.path.join(input_dir, f))
    ])


# === Render paragraphs ===
def render_paragraphs_on_image(canvas, paragraphs, font_path):
    for i, para in enumerate(paragraphs):
        try:
            text = para["translation"]
            (x1, y1) = para["top_left"]
            (x2, y2) = para["bottom_right"]
            box_w = x2 - x1
            box_h = y2 - y1

            # Try decreasing font size
            wrapped_text = None
            for font_size in range(min(max(int(box_h * 0.5), 8), 28), 3, -1):
                font = ImageFont.truetype(font_path, font_size)
                draw_test = ImageDraw.Draw(Image.new("RGB", (1, 1)))
                bbox = draw_test.textbbox((0, 0), "Ag", font=font)
                line_height = bbox[3] - bbox[1]
                line_spacing = int(line_height* 2)

                lines = []
                current_line = ""
                for word in text.split():
                    test_line = f"{current_line} {word}".strip()
                    test_bbox = draw_test.textbbox((0, 0), test_line, font=font)
                    if test_bbox[2] - test_bbox[0] <= box_w:
                        current_line = test_line
                    else:
                        lines.append(current_line)
                        current_line = word
                if current_line:
                    lines.append(current_line)

                total_height = len(lines) * line_spacing
                if total_height <= box_h:
                    wrapped_text = lines
                    break

            # Fallback
            if wrapped_text is None:
                font = ImageFont.truetype(font_path, 8)
                draw_test = ImageDraw.Draw(Image.new("RGB", (1, 1)))
                bbox = draw_test.textbbox((0, 0), "Ag", font=font)
                line_spacing = int((bbox[3] - bbox[1]) * 1)

                lines = []
                current_line = ""
                for word in text.split():
                    test_line = f"{current_line} {word}".strip()
                    test_bbox = draw_test.textbbox((0, 0), test_line, font=font)
                    if test_bbox[2] - test_bbox[0] <= box_w:
                        current_line = test_line
                    else:
                        lines.append(current_line)
                        current_line = word
                if current_line:
                    lines.append(current_line)
                wrapped_text = lines

            # Draw
            draw = ImageDraw.Draw(canvas)
            draw.rectangle([x1, y1, x2, y2], fill="white")
            y_cursor = y1
            for line in wrapped_text:
                draw.text((x1, y_cursor), line, fill="black", font=font)
                y_cursor += line_spacing

        except Exception as e:
            print(f"⚠️ Skipped paragraph {i} due to error: {e}")

# === Main Loop ===
for folder_path in folders_to_process:
    folder_name = os.path.basename(folder_path.rstrip("/"))
    output_pdf_path = os.path.join(output_root, f"{folder_name}_translated.pdf")
    output_images = []

    # --- SORT BY PAGE NUMBER ---
    import re
    def extract_page_number(filename):
        match = re.search(r"page_(\d+)_paragraphs\.json", filename)
        return int(match.group(1)) if match else float("inf")

    paragraph_files = sorted(
        (f for f in os.listdir(folder_path) if f.endswith("_paragraphs.json")),
        key=extract_page_number
    )

    for filename in tqdm(paragraph_files, desc=f"🖼 Rendering {folder_name}"):
        json_path = os.path.join(folder_path, filename)
        try:
            with open(json_path, "r", encoding="utf-8") as f:
                data = json.load(f)

            paragraphs = data.get("paragraphs", [])
            image_path = data.get("input_path")

            if not image_path:
                page_number = filename.replace("page_", "").replace("_paragraphs.json", "")
                image_name = f"page_{page_number}_ocr_res_img.png"
                image_path = os.path.join(folder_path, image_name)


            if not os.path.exists(image_path):
                print(f"❌ Image not found: {image_path}")
                continue

            original_image = Image.open(image_path).convert("RGBA")
            canvas = original_image.copy()
            render_paragraphs_on_image(canvas, paragraphs, font_path)
            output_images.append(canvas.convert("RGB"))

        except Exception as e:
            print(f"❌ Error processing {filename}: {e}")

    # Save output
    if output_images:
        output_images[0].save(output_pdf_path, save_all=True, append_images=output_images[1:])
        print(f"✅ PDF saved: {output_pdf_path}")
    else:
        print(f"⚠️ No images processed in {folder_name}")
