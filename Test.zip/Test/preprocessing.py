# preprocessing.py

import subprocess

def run_script(script_name):
    print(f"\n Running: {script_name}")
    try:
        subprocess.run(["python", script_name], check=True)
        print(f"✅ Finished: {script_name}")
    except subprocess.CalledProcessError as e:
        print(f"❌ Error running {script_name}: {e}")
        exit(1)

def run_preprocessing():
    print("🔧 Starting pre-processing pipeline...\n")
    run_script("convert.py")               # Step 0
    run_script("rename_chinese_pdfs.py")   # Step 0.5
    print("✅ Pre-processing completed.")

if __name__ == "__main__":
    run_preprocessing()
# This script handles the pre-processing steps for the PDF translation pipeline.