import os
import json
import requests
import re
from concurrent.futures import ThreadPoolExecutor, as_completed

# === API Configuration ===
BASE_URL = "http://77.37.126.131:8080/v1"
API_KEY = "hf-1234567"
MODEL_NAME = "NousResearch/Hermes-3-Llama-3.1-8B"
MAX_TOKENS = 12000

# === Helper: Clean and Format English Filename ===
def slugify(text):
    text = re.sub(r'[^\w\s-]', '', text)        # Remove special chars
    text = re.sub(r'\s+', '_', text.strip())    # Replace spaces with _
    return text[:100]                            # Limit to 50 chars

# === Translate Chinese Filename to English ===
def translate_filename(name: str) -> str:
    prompt = f'Translate this Chinese filename to clear and short English (keep it suitable as a file name): "{name}"'
    headers = {
        "Authorization": f"Bearer {API_KEY}",
        "Content-Type": "application/json"
    }

    payload = {
        "model": MODEL_NAME,
        "max_tokens": MAX_TOKENS,
        "messages": [
            {"role": "user", "content": prompt}
        ]
    }

    try:
        response = requests.post(f"{BASE_URL}/chat/completions", headers=headers, data=json.dumps(payload))
        response.raise_for_status()
        content = response.json()["choices"][0]["message"]["content"]
        return slugify(content)
    except Exception as e:
        print(f"❌ Error translating '{name}': {e}")
        return None

# === Rename a Single PDF File (in place) ===
def rename_pdf(file_path: str):
    if not file_path.lower().endswith(".pdf"):
        return

    dir_path = os.path.dirname(file_path)
    base_name = os.path.splitext(os.path.basename(file_path))[0].strip()

    translated_name = translate_filename(base_name)
    if translated_name:
        new_filename = translated_name + ".pdf"
        new_path = os.path.join(dir_path, new_filename)

        # Skip if already renamed
        if os.path.abspath(file_path) == os.path.abspath(new_path):
            print(f"⚠️ Already renamed: {file_path}")
            return

        # Avoid overwrite
        i = 1
        while os.path.exists(new_path):
            new_filename = f"{translated_name}_{i}.pdf"
            new_path = os.path.join(dir_path, new_filename)
            i += 1

        os.rename(file_path, new_path)
        print(f"✅ Renamed: {file_path} → {new_path}")

# === Collect all PDF files recursively ===
def collect_pdf_paths(folder_path):
    pdf_paths = []
    for root, _, files in os.walk(folder_path):
        for fname in files:
            if fname.lower().endswith(".pdf"):
                pdf_paths.append(os.path.join(root, fname))
    return pdf_paths

# === Main: Run threaded renaming ===
def process_path(input_path: str, max_workers=20):
    if os.path.isfile(input_path) and input_path.lower().endswith(".pdf"):
        rename_pdf(input_path)

    elif os.path.isdir(input_path):
        pdf_paths = collect_pdf_paths(input_path)
        print(f"🧾 Found {len(pdf_paths)} PDF files. Starting translation with {max_workers} threads...")

        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            futures = [executor.submit(rename_pdf, path) for path in pdf_paths]
            for future in as_completed(futures):
                _ = future.result()  # Triggers exceptions if any
    else:
        print("❌ Invalid path. Not a PDF or folder.")

# === Entry Point ===
if __name__ == "__main__":
    input_path = "/home/user/Desktop/paddle_ocr_pipeline/cn_data_translated"
    process_path(input_path, max_workers=20)  # You can increase thread count if your API/server can handle it
